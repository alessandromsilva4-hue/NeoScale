import { db } from './firebase.js';
import { collection, addDoc, serverTimestamp, getDocs } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const $=id=>document.getElementById(id);
const br=v=>Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const data=v=>v?.toDate?v.toDate().toLocaleString('pt-BR'):v?new Date(v).toLocaleString('pt-BR'):'—';
let caixas=[];
let caixaAtual=null;
let valoresSistema={dinheiro:0,pix:0,debito:0,credito:0};
let historicoFechados=[];
let filtroHistorico='todos';
let filtroPeriodo='todos', filtroOperador='', filtroStatus='todos';
let conciliacoesCaixaMap=new Map();
let conciliacoesDeliveryMap=new Map();
let caixasDelivery=[];

// O Fechamento possui leitura própria para não depender do módulo de caixa.
async function listarMovimentosFechamento(caixaId=null){
  const base=collection(db,'movimentosCaixa');
  const snap=caixaId
    ? await getDocs(base)
    : await getDocs(base);
  const lista=snap.docs.map(d=>({id:d.id,...d.data()}));
  return caixaId ? lista.filter(m=>String(m.caixaId||'')===String(caixaId)) : lista;
}
function calcularCaixaFechamento(caixa,movs){
  const entrada=movs.filter(m=>['VENDA','SUPRIMENTO'].includes(String(m.tipo||'').toUpperCase())).reduce((a,m)=>a+Number(m.valor||0),0);
  const saida=movs.filter(m=>['SANGRIA','DESPESA'].includes(String(m.tipo||'').toUpperCase())).reduce((a,m)=>a+Number(m.valor||0),0);
  return {entrada,saida,esperado:Number(caixa?.valorInicial||0)+entrada-saida};
}

function formaKey(v){
  const s=String(v||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  if(s.includes('dinheiro')) return 'dinheiro';
  if(s.includes('pix')) return 'pix';
  if(s.includes('debito')) return 'debito';
  if(s.includes('credito')) return 'credito';
  return null;
}
function valorInput(id){ return Math.max(0,Number($(id)?.value||0)); }
function setDiff(id,sys,conf){
  const d=conf-sys, el=$(id); if(!el)return; el.textContent=br(d);
  el.className=d===0?'conc-ok':'conc-divergente';
}
function atualizarConciliacao(){
  const map=[['dinheiro','sysDinheiro','maqDinheiro','difDinheiro'],['pix','sysPix','maqPix','difPix'],['debito','sysDebito','maqDebito','difDebito'],['credito','sysCredito','maqCredito','difCredito']];
  let totalS=0,totalC=0;
  for(const [k,si,mi,di] of map){ const sys=valoresSistema[k]||0, conf=valorInput(mi); totalS+=sys; totalC+=conf; $(si).textContent=br(sys); setDiff(di,sys,conf); }
  $('concTotalSistema').textContent=br(totalS); $('concTotalMaquina').textContent=br(totalC);
  const dif=totalC-totalS, status=$('statusConc');
  status.textContent=Math.abs(dif)<0.005?'CAIXA CONCILIADO':'DIVERGÊNCIA ENCONTRADA';
  $('resultadoConc').classList.toggle('conciliado',Math.abs(dif)<0.005);
}

async function obterColecaoSeguro(nome, ms=8000){
  const timeout=new Promise((_,rej)=>setTimeout(()=>rej(new Error('TIMEOUT_'+nome)),ms));
  const snap=await Promise.race([getDocs(collection(db,nome)),timeout]);
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}

async function carregarDados(){
 const tbody=$('tbody');
 if(tbody) tbody.innerHTML='<tr><td colspan="9" class="vazio"><i class="bi bi-arrow-repeat"></i><br>Carregando caixas...</td></tr>';
 if($('tbodyHistoricoCaixas')) $('tbodyHistoricoCaixas').innerHTML='<tr><td colspan="8" class="vazio"><i class="bi bi-arrow-repeat"></i><br>Carregando histórico...</td></tr>';
 try{
  // Busca os caixas diretamente, sem orderBy. Assim a tela não depende de índice do Firestore.
  caixas=await obterColecaoSeguro('caixas',8000);
  // Caixa Loja/PDV e Caixa Delivery são estruturas independentes.
  await carregarCaixasDelivery();
  caixas.sort((a,b)=>{const da=dataObj(a.abertoEm)?.getTime()||0, db=dataObj(b.abertoEm)?.getTime()||0; return db-da;});

  // Carrega também as conciliações já realizadas para não reapresentar caixas como PENDENTES.
  try{
    const [concL, concD]=await Promise.all([obterColecaoSeguro('conciliacoesCaixa',8000), obterColecaoSeguro('conciliacoesDelivery',8000)]);
    conciliacoesCaixaMap=new Map();
    for(const c of concL){ if(c.caixaId) conciliacoesCaixaMap.set(String(c.caixaId),{...c,id:c.id}); }
    conciliacoesDeliveryMap=new Map();
    for(const c of concD){ if(c.caixaId) conciliacoesDeliveryMap.set(String(c.caixaId),{...c,id:c.id}); }
  }catch(e){
    console.warn('Conciliações não puderam ser carregadas; os caixas serão tratados como não conciliados.',e);
    conciliacoesCaixaMap=new Map();
    conciliacoesDeliveryMap=new Map();
  }

  // Uma única leitura dos movimentos evita ficar esperando uma consulta para cada caixa.
  let movimentos=[];
  try{ movimentos=await obterColecaoSeguro('movimentosCaixa',8000); }
  catch(e){ console.warn('Movimentos não puderam ser carregados; caixas serão exibidos mesmo assim.',e); }
  const porCaixa=new Map();
  for(const m of movimentos){ if(!porCaixa.has(m.caixaId)) porCaixa.set(m.caixaId,[]); porCaixa.get(m.caixaId).push(m); }

  let vendas=0,ent=0,sai=0; const rows=[]; historicoFechados=[];
  for(const c of caixas){
    const ms=porCaixa.get(c.id)||[];
    const venda=ms.filter(m=>String(m.tipo||'').toUpperCase()==='VENDA').reduce((a,m)=>a+Number(m.valor||0),0);
    const x=calcularCaixaFechamento(c,ms); vendas+=venda; ent+=x.entrada; sai+=x.saida;
    const fechado=String(c.status||'').toUpperCase()==='FECHADO';
    const d=fechado?Number(c.valorContado||0)-x.esperado:0;
    c._vendas=venda; c._esperado=x.esperado; c._diferenca=d;
    rows.push(`<tr class="linha-caixa-resumo ${Math.abs(d)>=0.005&&fechado?'linha-divergente':''}" data-id="${c.id}" data-operador="${String(c.operador||'').toLowerCase()}" data-status="${fechado?'FECHADO':'ABERTO'}"><td><strong>${c.operador||'—'}</strong></td><td>${data(c.abertoEm)}</td><td>${data(c.fechadoEm)}</td><td>${br(venda)}</td><td>${br(x.esperado)}</td><td>${fechado?br(c.valorContado):'—'}</td><td class="${Math.abs(d)<0.005?'dif-ok':'dif-bad'}">${fechado?br(d):'—'}</td><td><span class="status-badge ${fechado?'status-fechado':'status-aberto'}">${fechado?'Fechado':'Aberto'}</span></td><td><button class="btn-ver-caixa" data-ver-caixa="${c.id}"><i class="bi bi-eye"></i> Ver</button></td></tr>`);
    if(fechado) historicoFechados.push({id:c.id,operador:c.operador||'Operador',abertoEm:c.abertoEm,fechadoEm:c.fechadoEm,venda,valorInicial:Number(c.valorInicial||0),valorContado:Number(c.valorContado||0),diferenca:d});
  }
  $('qtd').textContent=caixas.length; $('vendas').textContent=br(vendas); $('entradas').textContent=br(ent); $('saidas').textContent=br(sai);
  if(tbody) tbody.innerHTML=rows.length?rows.join(''):'<tr><td colspan="9" class="vazio"><i class="bi bi-inbox"></i><br>Nenhum caixa registrado ainda.</td></tr>';
  aplicarFiltrosFechamento();
  document.querySelectorAll('[data-ver-caixa]').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();abrirDetalheCaixa(btn.dataset.verCaixa);}));
  renderHistoricoFechados(); renderHistoricoConciliacoes(); preencherCaixas(); preencherCaixaDelivery(); atualizarConciliacaoDelivery();
 }catch(e){
  console.error('Erro ao carregar fechamento:',e);
  const msg=e?.message?.startsWith('TIMEOUT_')?'O Firestore demorou para responder. Verifique a conexão e tente Atualizar novamente.':'Não foi possível ler a coleção "caixas". Verifique as regras/permissões do Firestore.';
  if(tbody) tbody.innerHTML=`<tr><td colspan="9" class="vazio"><i class="bi bi-exclamation-triangle"></i><br>${msg}</td></tr>`;
  if($('tbodyHistoricoCaixas')) $('tbodyHistoricoCaixas').innerHTML=`<tr><td colspan="8" class="vazio"><i class="bi bi-exclamation-triangle"></i><br>${msg}</td></tr>`;
  if($('histQtdFechados')) $('histQtdFechados').textContent='0'; if($('histQtdConferidos')) $('histQtdConferidos').textContent='0';
  if($('histTotalContado')) $('histTotalContado').textContent=br(0); if($('histTotalVendas')) $('histTotalVendas').textContent=br(0); if($('histTotalDiferenca')) $('histTotalDiferenca').textContent=br(0);
 }
}

function dataObj(v){
 const d=v?.toDate?v.toDate():(v?new Date(v):null);
 return d&&!Number.isNaN(d.getTime())?d:null;
}
function renderHistoricoFechados(){
 const tbody=$('tbodyHistoricoCaixas'); if(!tbody)return;
 const agora=new Date(); agora.setHours(0,0,0,0);
 let lista=historicoFechados.slice();
 if(filtroHistorico!=='todos'){
  const dias=Number(filtroHistorico);
  const limite=new Date(agora); limite.setDate(limite.getDate()-dias+1);
  lista=lista.filter(c=>{const d=dataObj(c.fechadoEm); return d&&d>=limite;});
 }
 lista.sort((a,b)=>(dataObj(b.fechadoEm)?.getTime()||0)-(dataObj(a.fechadoEm)?.getTime()||0));
 const totalContado=lista.reduce((a,c)=>a+c.valorContado,0);
 const totalVendas=lista.reduce((a,c)=>a+c.venda,0);
 const totalDif=lista.reduce((a,c)=>a+c.diferenca,0);
 $('histQtdFechados').textContent=lista.length; if($('histQtdConferidos')) $('histQtdConferidos').textContent=lista.filter(c=>Math.abs(c.diferenca)<0.005).length; $('histTotalContado').textContent=br(totalContado); $('histTotalVendas').textContent=br(totalVendas);
 const difEl=$('histTotalDiferenca'); difEl.textContent=br(totalDif); difEl.className=Math.abs(totalDif)<0.005?'dif-ok':'dif-bad';
 if(!lista.length){tbody.innerHTML='<tr><td colspan="8" class="vazio"><i class="bi bi-clock-history"></i><br>Nenhum caixa fechado encontrado neste período.</td></tr>';return;}
 tbody.innerHTML=lista.map(c=>`<tr class="linha-caixa-clicavel" data-caixa-id="${c.id}" tabindex="0" role="button" aria-label="Abrir detalhes do caixa de ${c.operador}"><td><span class="operador-clicavel"><i class="bi bi-box-arrow-up-right"></i>${c.operador}</span></td><td>${data(c.abertoEm)}</td><td>${data(c.fechadoEm)}</td><td>${br(c.venda)}</td><td>${br(c.valorInicial)}</td><td>${br(c.valorContado)}</td><td class="${Math.abs(c.diferenca)<0.005?'dif-ok':'dif-bad'}">${br(c.diferenca)}</td><td><span class="status-badge status-fechado"><i class="bi bi-check-circle"></i>Fechado</span></td></tr>`).join('');
 tbody.querySelectorAll('.linha-caixa-clicavel').forEach(row=>{
   row.addEventListener('click',()=>abrirDetalheCaixa(row.dataset.caixaId));
   row.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();abrirDetalheCaixa(row.dataset.caixaId);}});
 });
}

async function abrirDetalheCaixa(id){
 const caixa=caixas.find(c=>c.id===id);
 if(!caixa)return;
 const modal=$('modalDetalheCaixa');
 modal?.classList.add('show');
 modal?.setAttribute('aria-hidden','false');
 $('tituloDetalheCaixa').textContent=`Caixa de ${caixa.operador||'Operador'}`;
 $('subtituloDetalheCaixa').textContent=`Fechado em ${data(caixa.fechadoEm)} • ${caixa.id}`;
 $('detalheKpis').innerHTML='<div class="detalhe-kpi carregando-kpi"><i class="bi bi-arrow-repeat"></i> Carregando detalhes...</div>';
 $('detalheDadosCaixa').innerHTML=''; $('detalhePagamentos').innerHTML=''; $('tbodyDetalheMovimentos').innerHTML='';
 try{
  const ms=await listarMovimentosFechamento(id);
  const calc=calcularCaixaFechamento(caixa,ms);
  const vendaMov=ms.filter(m=>m.tipo==='VENDA');
  const pagamentos={dinheiro:0,pix:0,debito:0,credito:0,outros:0};
  vendaMov.forEach(m=>{const k=formaKey(m.forma); pagamentos[k||'outros']+=Number(m.valor||0);});
  const diferenca=Number(caixa.valorContado||0)-calc.esperado;
  const entrada=calc.entrada, saida=calc.saida;
  $('detalheKpis').innerHTML=`
   <div class="detalhe-kpi"><span>Vendas</span><strong>${br(vendaMov.reduce((a,m)=>a+Number(m.valor||0),0))}</strong><small>${vendaMov.length} venda(s)</small></div>
   <div class="detalhe-kpi"><span>Valor esperado</span><strong>${br(calc.esperado)}</strong><small>Inicial + entradas − saídas</small></div>
   <div class="detalhe-kpi"><span>Valor contado</span><strong>${br(caixa.valorContado)}</strong><small>Informado no fechamento</small></div>
   <div class="detalhe-kpi ${Math.abs(diferenca)<0.005?'ok':'bad'}"><span>Diferença</span><strong>${br(diferenca)}</strong><small>${Math.abs(diferenca)<0.005?'Caixa conferido':'Sobra / falta'}</small></div>`;
  $('detalheDadosCaixa').innerHTML=`
   <div><span>Operador</span><strong>${caixa.operador||'—'}</strong></div>
   <div><span>Abertura</span><strong>${data(caixa.abertoEm)}</strong></div>
   <div><span>Fechamento</span><strong>${data(caixa.fechadoEm)}</strong></div>
   <div><span>Valor inicial</span><strong>${br(caixa.valorInicial)}</strong></div>
   <div><span>Entradas</span><strong>${br(entrada)}</strong></div>
   <div><span>Saídas</span><strong>${br(saida)}</strong></div>`;
  const nomes={dinheiro:'Dinheiro',pix:'PIX',debito:'Débito',credito:'Crédito',outros:'Outros'};
  $('detalhePagamentos').innerHTML=Object.entries(pagamentos).filter(([,v])=>v>0).map(([k,v])=>`<div><span><i class="bi ${k==='dinheiro'?'bi-cash-stack':k==='pix'?'bi-qr-code':'bi-credit-card'}"></i>${nomes[k]}</span><strong>${br(v)}</strong></div>`).join('')||'<div class="detalhe-vazio">Nenhuma venda registrada.</div>';
  $('tbodyDetalheMovimentos').innerHTML=ms.length?ms.map(m=>`<tr><td>${data(m.criadoEm)}</td><td><span class="mov-badge mov-${String(m.tipo||'').toLowerCase()}">${m.tipo||'—'}</span></td><td>${m.descricao||'—'}</td><td>${m.forma||'—'}</td><td class="${['SANGRIA','DESPESA'].includes(m.tipo)?'dif-bad':''}">${br(m.valor)}</td></tr>`).join(''):'<tr><td colspan="5" class="vazio">Nenhuma movimentação registrada neste caixa.</td></tr>';
 }catch(e){console.error(e);$('detalheKpis').innerHTML='<div class="detalhe-erro"><i class="bi bi-exclamation-triangle"></i> Não foi possível carregar os detalhes deste caixa.</div>';$('tbodyDetalheMovimentos').innerHTML='<tr><td colspan="5" class="vazio">Erro ao carregar movimentações.</td></tr>';}
}
function fecharDetalheCaixa(){const m=$('modalDetalheCaixa');m?.classList.remove('show');m?.setAttribute('aria-hidden','true');}
function configurarDetalheCaixa(){
 $('fecharDetalheCaixa')?.addEventListener('click',fecharDetalheCaixa);
 $('btnFecharDetalheFinal')?.addEventListener('click',fecharDetalheCaixa);
 document.querySelector('[data-fechar-detalhe]')?.addEventListener('click',fecharDetalheCaixa);
 document.addEventListener('keydown',e=>{if(e.key==='Escape')fecharDetalheCaixa();});
}

function renderHistoricoConciliacoes(){
 const tbody=$('tbodyHistoricoConciliacoes'); if(!tbody)return;
 const lista=Array.from(conciliacoesCaixaMap.values()).map(c=>({...c,_tipo:'Caixa Loja',_operador:c.operador||'Operador',_caixaId:c.caixaId,_data:c.criadoEm})).sort((a,b)=>(dataObj(b._data)?.getTime()||0)-(dataObj(a._data)?.getTime()||0));
 const qtdOk=lista.filter(c=>String(c.status||'').toUpperCase()==='CONCILIADO').length;
 const qtdDiv=lista.filter(c=>String(c.status||'').toUpperCase()==='DIVERGENTE').length;
 const totalS=lista.reduce((a,c)=>a+Number(c.totalSistema||0),0);
 const totalC=lista.reduce((a,c)=>a+Number(c.totalConferido||0),0);
 if($('concHistQtd'))$('concHistQtd').textContent=lista.length;
 if($('concHistQtdOk'))$('concHistQtdOk').textContent=qtdOk;
 if($('concHistQtdDiv'))$('concHistQtdDiv').textContent=qtdDiv;
 if($('concHistTotalSistema'))$('concHistTotalSistema').textContent=br(totalS);
 if($('concHistTotalConferido'))$('concHistTotalConferido').textContent=br(totalC);
 if(!lista.length){tbody.innerHTML='<tr><td colspan="8" class="vazio"><i class="bi bi-check2-all"></i><br>Nenhuma conciliação do Caixa Loja realizada ainda.</td></tr>';return;}
 tbody.innerHTML=lista.map(c=>{
   const st=String(c.status||'').toUpperCase(), dif=Number(c.diferenca||0);
   const badge=st==='CONCILIADO'?'<span class="status-badge status-fechado"><i class="bi bi-check-circle"></i> Conciliado</span>':'<span class="status-badge status-divergente"><i class="bi bi-exclamation-triangle"></i> Divergente</span>';
   return `<tr><td>${c._operador}</td><td>${c._caixaId||'—'}</td><td>${data(c._data)}</td><td>${br(c.totalSistema)}</td><td>${br(c.totalConferido)}</td><td class="${Math.abs(dif)<0.005?'dif-ok':'dif-bad'}">${br(dif)}</td><td>${badge}</td><td><button type="button" class="btn-ver-caixa btn-ver-conciliacao" data-ver-conc="${c.id||''}"><i class="bi bi-eye"></i> Ver</button></td></tr>`;
 }).join('');
 tbody.querySelectorAll('[data-ver-conc]').forEach(btn=>btn.addEventListener('click',()=>abrirDetalheConciliacao(btn.dataset.verConc)));
 renderHistoricoConciliacoesDelivery();
}
function renderHistoricoConciliacoesDelivery(){
 const tbody=$('tbodyHistoricoConciliacoesDelivery'); if(!tbody)return;
 const lista=Array.from(conciliacoesDeliveryMap.values()).map(c=>({...c,_data:c.criadoEm})).sort((a,b)=>(dataObj(b._data)?.getTime()||0)-(dataObj(a._data)?.getTime()||0));
 const qtdOk=lista.filter(c=>String(c.status||'').toUpperCase()==='CONCILIADO').length;
 const qtdDiv=lista.filter(c=>String(c.status||'').toUpperCase()==='DIVERGENTE').length;
 const totalS=lista.reduce((a,c)=>a+Number(c.totalSistema||0),0);
 const totalC=lista.reduce((a,c)=>a+Number(c.totalConferido||0),0);
 if($('concDeliveryHistQtd'))$('concDeliveryHistQtd').textContent=lista.length;
 if($('concDeliveryHistQtdOk'))$('concDeliveryHistQtdOk').textContent=qtdOk;
 if($('concDeliveryHistQtdDiv'))$('concDeliveryHistQtdDiv').textContent=qtdDiv;
 if($('concDeliveryHistTotalSistema'))$('concDeliveryHistTotalSistema').textContent=br(totalS);
 if($('concDeliveryHistTotalConferido'))$('concDeliveryHistTotalConferido').textContent=br(totalC);
 if(!lista.length){tbody.innerHTML='<tr><td colspan="11" class="vazio"><i class="bi bi-bicycle"></i><br>Nenhuma conciliação do Delivery realizada ainda.</td></tr>';return;}
 const money=(obj,key)=>br(Number((obj||{})[key]||0));
 tbody.innerHTML=lista.map(c=>{
   const st=String(c.status||'').toUpperCase(), dif=Number(c.diferenca||0), conf=c.conferidoPorPlataforma||{}, sys=c.sistemaPorPlataforma||{};
   const badge=st==='CONCILIADO'?'<span class="status-badge status-fechado"><i class="bi bi-check-circle"></i> Conciliado</span>':'<span class="status-badge status-divergente"><i class="bi bi-exclamation-triangle"></i> Divergente</span>';
   return `<tr><td>${c.caixaId||'—'}</td><td>${data(c._data)}</td><td>${money(conf,'ifood')}</td><td>${money(conf,'99food')}</td><td>${money(conf,'anota')}</td><td>${money(conf,'balcao')}</td><td>${br(c.totalSistema)}</td><td>${br(c.totalConferido)}</td><td class="${Math.abs(dif)<0.005?'dif-ok':'dif-bad'}">${br(dif)}</td><td>${badge}</td><td><button type="button" class="btn-ver-caixa btn-ver-conciliacao" data-ver-conc-delivery="${c.id||''}"><i class="bi bi-eye"></i> Ver</button></td></tr>`;
 }).join('');
 tbody.querySelectorAll('[data-ver-conc-delivery]').forEach(btn=>btn.addEventListener('click',()=>abrirDetalheConciliacao(btn.dataset.verConcDelivery)));
}

function abrirDetalheConciliacao(id){
 const c=conciliacoesCaixaMap.get(id)||conciliacoesDeliveryMap.get(id); if(!c)return;
 const tipo=conciliacoesCaixaMap.has(id)?'Caixa Loja':'Caixa Delivery';
 const detalhes=tipo==='Caixa Loja'
  ? `Dinheiro: ${br(c.conferencia?.dinheiro)} | PIX: ${br(c.conferencia?.pix)} | Débito: ${br(c.conferencia?.debito)} | Crédito: ${br(c.conferencia?.credito)}`
  : Object.entries(c.conferidoPorPlataforma||{}).map(([k,v])=>`${k}: ${br(v)}`).join(' | ');
 alert(`Conciliação ${tipo}\n\nOperador: ${c.operador||'—'}\nCaixa: ${c.caixaId||'—'}\nData: ${data(c.criadoEm)}\nStatus: ${c.status||'—'}\nTotal sistema: ${br(c.totalSistema)}\nTotal conferido: ${br(c.totalConferido)}\nDiferença: ${br(c.diferenca)}\n\nValores conferidos:\n${detalhes}\n\nObservação: ${c.observacao||'—'}`);
}

function caixasPendentesConciliacao(){
 return caixas.filter(c=>String(c.status||'').toUpperCase()==='FECHADO' && !conciliacoesCaixaMap.has(String(c.id)));
}
function preencherCaixas(){
 const sel=$('caixaConciliacao'); if(!sel)return;
 const pendentes=caixasPendentesConciliacao();
 sel.innerHTML=pendentes.map(c=>`<option value="${c.id}">${c.operador||'Operador'} — ${data(c.fechadoEm)} — ${br(c.valorContado)}</option>`).join('');
 if(!sel.options.length){sel.innerHTML='<option value="">Nenhum caixa para conciliar</option>';$('carregarConciliacao').disabled=true;$('salvarConciliacao').disabled=true;$('statusConc').textContent='SEM CAIXA PARA CONCILIAR';$('resultadoConc')?.classList.remove('conciliado');$('concAlerta').innerHTML='<i class="bi bi-check-circle"></i> Não há caixa fechado aguardando conciliação.';return;}
 $('carregarConciliacao').disabled=false;$('salvarConciliacao').disabled=false;$('statusConc').textContent='PENDENTE';
}

async function prepararConciliacao(){
 const id=$('caixaConciliacao').value; caixaAtual=caixas.find(c=>c.id===id);
 if(!caixaAtual){$('salvarConciliacao').disabled=true;$('statusConc').textContent='SEM CAIXA PARA CONCILIAR';$('resultadoConc')?.classList.remove('conciliado');$('concAlerta').innerHTML='<i class="bi bi-info-circle"></i> Não há caixa fechado disponível para conciliar.';return;}
 $('salvarConciliacao').disabled=false;
 try{
  const ms=await listarMovimentosFechamento(id); valoresSistema={dinheiro:0,pix:0,debito:0,credito:0};
  ms.filter(m=>m.tipo==='VENDA').forEach(m=>{const k=formaKey(m.forma);if(k)valoresSistema[k]+=Number(m.valor||0);});
  ['dinheiro','pix','debito','credito'].forEach(k=>{const id='maq'+k.charAt(0).toUpperCase()+k.slice(1);$(id).value=k==='dinheiro'?Number(caixaAtual.valorContado||0):'';});
  $('concAlerta').innerHTML='<i class="bi bi-check-circle"></i> Caixa selecionado. Informe os valores do fechamento do dinheiro e dos relatórios de PIX/maquininhas para conferir.';
  atualizarConciliacao();
 }catch(e){console.error(e);$('concAlerta').innerHTML='<i class="bi bi-exclamation-triangle"></i> Não foi possível carregar os movimentos deste caixa.';}
}

async function salvarConciliacao(){
 if(!caixaAtual){alert('Selecione um caixa fechado primeiro.');return;}
 atualizarConciliacao();
 const conferencia={dinheiro:valorInput('maqDinheiro'),pix:valorInput('maqPix'),debito:valorInput('maqDebito'),credito:valorInput('maqCredito')};
 const observacao=String($('obsConciliacao')?.value||'').trim();
 const sistema={...valoresSistema}; const totalSistema=Object.values(sistema).reduce((a,b)=>a+b,0); const totalConferido=Object.values(conferencia).reduce((a,b)=>a+b,0);
 const diferenca=totalConferido-totalSistema;
 if(Math.abs(diferenca)>=0.005 && !observacao){ alert('Informe uma observação/justificativa para salvar uma conciliação com divergência.'); $('obsConciliacao')?.focus(); return; }
 try{
  await addDoc(collection(db,'conciliacoesCaixa'),{caixaId:caixaAtual.id,operador:caixaAtual.operador||'Operador',sistema,conferencia,totalSistema,totalConferido,diferenca,status:Math.abs(diferenca)<0.005?'CONCILIADO':'DIVERGENTE',observacao,criadoEm:serverTimestamp()});
  const novo={caixaId:caixaAtual.id,operador:caixaAtual.operador||'Operador',sistema,conferencia,totalSistema,totalConferido,diferenca,status:Math.abs(diferenca)<0.005?'CONCILIADO':'DIVERGENTE',observacao,criadoEm:new Date(),id:'local-'+caixaAtual.id};
  conciliacoesCaixaMap.set(String(caixaAtual.id),novo);
  renderHistoricoConciliacoes();
  preencherCaixas();
  $('concAlerta').innerHTML='<i class="bi bi-check-circle-fill"></i> Conciliação salva no Firestore com sucesso.';
 }catch(e){console.error(e);alert('Não foi possível salvar a conciliação.');}
}


function dentroPeriodo(c, periodo){
 if(periodo==='todos') return true;
 const d=dataObj(c.abertoEm); if(!d)return false;
 const hoje=new Date(); hoje.setHours(0,0,0,0); d.setHours(0,0,0,0);
 if(periodo==='hoje') return d.getTime()===hoje.getTime();
 const dias=Number(periodo); const limite=new Date(hoje); limite.setDate(limite.getDate()-dias+1); return d>=limite;
}
function aplicarFiltrosFechamento(){
 document.querySelectorAll('#tbody .linha-caixa-resumo').forEach(row=>{
  const id=row.dataset.id, c=caixas.find(x=>x.id===id); if(!c)return;
  const operador=(row.dataset.operador||''); const status=row.dataset.status;
  const okBusca=!filtroOperador||operador.includes(filtroOperador.toLowerCase());
  const okPeriodo=dentroPeriodo(c,filtroPeriodo);
  const dif=Math.abs(Number(c._diferenca||0))>=0.005;
  const okStatus=filtroStatus==='todos'||status===filtroStatus||(filtroStatus==='DIVERGENTE'&&status==='FECHADO'&&dif);
  row.style.display=okBusca&&okPeriodo&&okStatus?'':'none';
 });
}
function csvEsc(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
function exportarFechamento(){
 const linhas=[['Operador','Abertura','Fechamento','Vendas','Valor esperado','Valor contado','Diferença','Status']];
 caixas.filter(c=>c.status==='FECHADO').forEach(c=>linhas.push([c.operador||'',data(c.abertoEm),data(c.fechadoEm),Number(c._vendas||0).toFixed(2).replace('.',','),Number(c._esperado||0).toFixed(2).replace('.',','),Number(c.valorContado||0).toFixed(2).replace('.',','),Number(c._diferenca||0).toFixed(2).replace('.',','),Math.abs(Number(c._diferenca||0))<0.005?'CONFERIDO':'DIVERGENTE']));
 const blob=new Blob(['\ufeff'+linhas.map(l=>l.map(csvEsc).join(';')).join('\n')],{type:'text/csv;charset=utf-8;'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='fechamento-neoscale.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function imprimirFechamento(){window.print();}

// Conciliação Caixa Delivery — mesma estrutura visual e operacional da Caixa Loja
const DELIVERY_PLATFORMS=[
 ['ifood','iFood','deliverySysIfood','deliveryMaqIfood','deliveryDifIfood'],
 ['food99','99Food','deliverySys99','deliveryMaq99','deliveryDif99'],
 ['anota','Anota aí','deliverySysAnota','deliveryMaqAnota','deliveryDifAnota'],
 ['balcao','Pedido no balcão','deliverySysBalcao','deliveryMaqBalcao','deliveryDifBalcao']
];
function inicializarFechamento(){
  const on=(id,evento,fn)=>{const el=$(id); if(el) el.addEventListener(evento,fn);};
  on('atualizar','click',carregarDados);
  on('imprimirFechamento','click',imprimirFechamento);
  on('exportarFechamento','click',exportarFechamento);
  on('filtroPeriodo','change',e=>{filtroPeriodo=e.target.value;aplicarFiltrosFechamento();});
  on('filtroStatus','change',e=>{filtroStatus=e.target.value;aplicarFiltrosFechamento();});
  on('filtroOperador','input',e=>{filtroOperador=e.target.value.trim();aplicarFiltrosFechamento();});
  on('limparFiltros','click',()=>{filtroPeriodo='todos';filtroStatus='todos';filtroOperador='';if($('filtroPeriodo'))$('filtroPeriodo').value='todos';if($('filtroStatus'))$('filtroStatus').value='todos';if($('filtroOperador'))$('filtroOperador').value='';aplicarFiltrosFechamento();});
  on('carregarConciliacao','click',prepararConciliacao);
  on('salvarConciliacao','click',salvarConciliacao);
  ['maqDinheiro','maqPix','maqDebito','maqCredito'].forEach(id=>on(id,'input',atualizarConciliacao));
  on('obsConciliacao','input',()=>{const el=$('contadorObs');if(el)el.textContent=String($('obsConciliacao').value.length);});
  configurarDetalheCaixa();
  document.querySelectorAll('.filtro-caixa').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.filtro-caixa').forEach(b=>b.classList.remove('ativo'));btn.classList.add('ativo');filtroHistorico=btn.dataset.filtro;renderHistoricoFechados();}));
  // Os botões de "Ver" e as linhas do histórico são dinâmicos; a delegação mantém tudo clicável.
  $('tbody')?.addEventListener('click',e=>{const btn=e.target.closest('[data-ver-caixa]');if(btn){e.preventDefault();e.stopPropagation();abrirDetalheCaixa(btn.dataset.verCaixa);}});
  $('tbodyHistoricoCaixas')?.addEventListener('click',e=>{const row=e.target.closest('.linha-caixa-clicavel');if(row)abrirDetalheCaixa(row.dataset.caixaId);});
  // Conciliação Delivery: todos os eventos ficam ligados somente após o DOM estar pronto.
  DELIVERY_PLATFORMS.forEach(([, , ,mid])=>on(mid,'input',atualizarConciliacaoDelivery));
  on('deliveryConcObs','input',()=>{const el=$('deliveryContadorObs');if(el)el.textContent=String($('deliveryConcObs')?.value||'').length;});
  on('carregarConciliacaoDelivery','click',prepararConciliacaoDelivery);
  on('salvarConciliacaoDelivery','click',salvarConciliacaoDelivery);
  preencherCaixaDelivery();
  atualizarConciliacaoDelivery();
  carregarDados();
}

// Garante que a página já esteja pronta antes de conectar os eventos.
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',inicializarFechamento,{once:true});
else inicializarFechamento();



function pedidosDeliveryConcluidos(){
 try{
  const rows=JSON.parse(localStorage.getItem('neoscale_delivery_orders')||'[]');
  return Array.isArray(rows)?rows.filter(o=>String(o.status||o.state||'').toLowerCase().includes('concl') || String(o.status||o.state||'').toLowerCase()==='finalizado'):rows;
 }catch{return []}
}
function chavePlataformaDelivery(v){
 const s=String(v||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
 if(s.includes('ifood'))return 'ifood'; if(s.includes('99food')||s.includes('99 food'))return 'food99'; if(s.includes('anota'))return 'anota'; if(s.includes('balcao')||s.includes('balcão'))return 'balcao'; return null;
}
function valoresSistemaDelivery(){
 const out={ifood:0,food99:0,anota:0,balcao:0};
 for(const o of pedidosDeliveryConcluidos()){
  const k=chavePlataformaDelivery(o.source||o.platform||o.canal||o.origem);
  if(k)out[k]+=Number(o.total||o.valor||0);
 }
 return out;
}
function atualizarConciliacaoDelivery(){
 const sistema=valoresSistemaDelivery(); let totalS=0,totalC=0;
 for(const [k,,sid,mid,did] of DELIVERY_PLATFORMS){
  const sys=Number(sistema[k]||0), conf=valorInput(mid), dif=conf-sys;
  totalS+=sys; totalC+=conf;
  if($(sid))$(sid).textContent=br(sys);
  setDiff(did,sys,conf);
 }
 if($('deliveryConcTotalSistema'))$('deliveryConcTotalSistema').textContent=br(totalS);
 if($('deliveryConcTotalConferido'))$('deliveryConcTotalConferido').textContent=br(totalC);
 const dif=totalC-totalS;
 if($('deliveryConcDiferenca'))$('deliveryConcDiferenca').textContent=Math.abs(dif)<0.005?'CONCILIADO':br(dif);
 $('deliveryConcResultado')?.classList.toggle('conciliado',Math.abs(dif)<0.005);
}
async function carregarCaixasDelivery(){
 try{
  const snap=await getDocs(collection(db,'caixasDelivery'));
  caixasDelivery=snap.docs.map(d=>({id:d.id,...d.data()}));
  caixasDelivery.sort((a,b)=>(dataObj(b.fechadoEm||b.abertoEm)?.getTime()||0)-(dataObj(a.fechadoEm||a.abertoEm)?.getTime()||0));
 }catch(e){
  console.error('Não foi possível carregar os caixas do Delivery:',e);
  caixasDelivery=[];
 }
}
function preencherCaixaDelivery(){
 const sel=$('caixaConciliacaoDelivery'); if(!sel)return;
 // IMPORTANTE: a conciliação Delivery usa exclusivamente a coleção caixasDelivery.
 // Nunca utilizar a coleção caixas, que pertence ao Frente de Loja/PDV.
 const fechados=caixasDelivery.filter(c=>String(c.status||'').toUpperCase()==='FECHADO' && !conciliacoesDeliveryMap.has(String(c.id)));
 sel.innerHTML=fechados.map(c=>`<option value="${c.id}">${c.operador||'Operador'} — ${data(c.fechadoEm)} — ${br(c.valorContado)}</option>`).join('');
 if(!sel.options.length){sel.innerHTML='<option value="">Nenhum caixa Delivery fechado</option>';$('salvarConciliacaoDelivery')?.setAttribute('disabled','disabled');if($('deliveryConcDiferenca'))$('deliveryConcDiferenca').textContent='SEM CAIXA DELIVERY PARA CONCILIAR';$('deliveryConcResultado')?.classList.remove('conciliado');if($('deliveryConcAlerta'))$('deliveryConcAlerta').innerHTML='<i class="bi bi-info-circle"></i> Não há caixa Delivery fechado para realizar a conciliação.';} else {$('salvarConciliacaoDelivery')?.removeAttribute('disabled');if($('deliveryConcDiferenca'))$('deliveryConcDiferenca').textContent='PENDENTE';}
}
async function prepararConciliacaoDelivery(){
 await carregarCaixasDelivery();
 preencherCaixaDelivery(); atualizarConciliacaoDelivery();
 const sel=$('caixaConciliacaoDelivery');
 if(sel?.value) $('deliveryConcAlerta').innerHTML='<i class="bi bi-check-circle"></i> Caixa selecionado. Confira os valores dos relatórios de cada plataforma do Delivery.';
}
async function salvarConciliacaoDelivery(){
 atualizarConciliacaoDelivery();
 const sistema=valoresSistemaDelivery();
 const conferido={}; let totalS=0,totalC=0;
 for(const [k,,sid,mid] of DELIVERY_PLATFORMS){const sys=Number(sistema[k]||0),conf=valorInput(mid);conferido[k]=conf;totalS+=sys;totalC+=conf;}
 const diferenca=totalC-totalS, observacao=String($('deliveryConcObs')?.value||'').trim();
 if(Math.abs(diferenca)>=0.005&&!observacao){alert('Informe uma observação/justificativa para salvar uma divergência no Delivery.');return;}
 try{const caixaId=$('caixaConciliacaoDelivery')?.value||null; await addDoc(collection(db,'conciliacoesDelivery'),{sistemaPorPlataforma:sistema,conferidoPorPlataforma:conferido,totalSistema:totalS,totalConferido:totalC,diferenca,status:Math.abs(diferenca)<0.005?'CONCILIADO':'DIVERGENTE',observacao,caixaId,criadoEm:serverTimestamp()}); if(caixaId){conciliacoesDeliveryMap.set(String(caixaId),{caixaId,sistemaPorPlataforma:sistema,conferidoPorPlataforma:conferido,totalSistema:totalS,totalConferido:totalC,diferenca,status:Math.abs(diferenca)<0.005?'CONCILIADO':'DIVERGENTE',observacao,criadoEm:new Date(),id:'local-'+caixaId});} renderHistoricoConciliacoes(); preencherCaixaDelivery(); alert('Conciliação Caixa Delivery salva com sucesso.');}
 catch(e){console.error(e);alert('Não foi possível salvar a conciliação do Delivery.');}
}


window.addEventListener('error',e=>console.error('NeoScale Fechamento erro:',e.error||e.message));
window.addEventListener('unhandledrejection',e=>console.error('NeoScale Fechamento promessa rejeitada:',e.reason));
